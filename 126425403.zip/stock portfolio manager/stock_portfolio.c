#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#define MAX_INVESTMENTS 100
#define TICKER_LEN 10

// One investment record
typedef struct {
  char ticker[TICKER_LEN];
  int shares;
  float price;
} Investment;

// ---------- Helper functions ----------

bool read_line(char *buffer, int size) {
  if (fgets(buffer, size, stdin) == NULL) {
    return false;
  }

  int n = strlen(buffer);
  if (n > 0 && buffer[n - 1] == '\n') {
    buffer[n - 1] = '\0';
  }
  return true;
}

void to_uppercase(char *s) {
  for (int i = 0; s[i] != '\0'; i++) {
    s[i] = toupper((unsigned char)s[i]);
  }
}

int get_int(const char *prompt) {
  char line[100];
  int value;

  while (true) {
    printf("%s", prompt);
    if (!read_line(line, sizeof(line))) {
      continue;
    }

    if (sscanf(line, "%d", &value) == 1) {
      return value;
    }

    printf("Invalid integer. Try again.\n");
  }
}

float get_float(const char *prompt) {
  char line[100];
  float value;

  while (true) {
    printf("%s", prompt);
    if (!read_line(line, sizeof(line))) {
      continue;
    }

    if (sscanf(line, "%f", &value) == 1) {
      return value;
    }

    printf("Invalid number. Try again.\n");
  }
}

// ---------- Portfolio functions ----------

void add_investment(Investment investments[], int *count) {
  if (*count >= MAX_INVESTMENTS) {
    printf("Investment list is full.\n");
    return;
  }

  char ticker[TICKER_LEN];
  printf("Ticker: ");
  if (!read_line(ticker, sizeof(ticker))) {
    return;
  }
  to_uppercase(ticker);

  int shares = get_int("Shares: ");
  float price = get_float("Price per share: ");

  if (shares <= 0 || price <= 0) {
    printf("Invalid input.\n");
    return;
  }

  strcpy(investments[*count].ticker, ticker);
  investments[*count].shares = shares;
  investments[*count].price = price;
  (*count)++;

  printf("Investment added.\n");
}

void view_portfolio(Investment investments[], int count) {
  printf("\n--- INVESTMENT TRACKER ---\n");

  if (count == 0) {
    printf("No investments recorded.\n");
    return;
  }

  for (int i = 0; i < count; i++) {
    float value = investments[i].shares * investments[i].price;
    printf("%-8s  shares: %-5d  price: $%-7.2f  value: $%.2f\n",
           investments[i].ticker, investments[i].shares, investments[i].price,
           value);
  }
}

void total_invested(Investment investments[], int count) {
  float grand_total = 0.0f;

  printf("\n--- INVESTMENT SUMMARY ---\n");

  if (count == 0) {
    printf("No investments recorded.\n");
    return;
  }

  for (int i = 0; i < count; i++) {
    float total = investments[i].shares * investments[i].price;
    grand_total += total;

    printf("%-8s  shares: %-5d  price: $%-7.2f  total: $%.2f\n",
           investments[i].ticker, investments[i].shares, investments[i].price,
           total);
  }

  printf("\nTotal invested across all investments: $%.2f\n", grand_total);
}

void save_to_file(Investment investments[], int count) {
  char filename[100];
  printf("Save filename: ");
  if (!read_line(filename, sizeof(filename))) {
    return;
  }

  FILE *f = fopen(filename, "w");
  if (f == NULL) {
    printf("Could not open file.\n");
    return;
  }

  fprintf(f, "%d\n", count);

  for (int i = 0; i < count; i++) {
    fprintf(f, "%s %d %.2f\n", investments[i].ticker, investments[i].shares,
            investments[i].price);
  }

  fclose(f);
  printf("Saved.\n");
}

void load_from_file(Investment investments[], int *count) {
  char filename[100];
  printf("Load filename: ");
  if (!read_line(filename, sizeof(filename))) {
    return;
  }

  FILE *f = fopen(filename, "r");
  if (f == NULL) {
    printf("Could not open file.\n");
    return;
  }

  fscanf(f, "%d", count);

  for (int i = 0; i < *count; i++) {
    fscanf(f, "%9s %d %f", investments[i].ticker, &investments[i].shares,
           &investments[i].price);
  }

  fclose(f);
  printf("Loaded.\n");
}

// ---------- Menu ----------

void print_menu(void) {
  printf("\n==== INVESTMENT TRACKER ====\n");
  printf("1) View investments\n");
  printf("2) Add investment\n");
  printf("3) Total invested\n");
  printf("4) Save to file\n");
  printf("5) Load from file\n");
  printf("0) Exit\n");
}

int main(void) {
  Investment investments[MAX_INVESTMENTS];
  int count = 0;

  while (true) {
    print_menu();
    int choice = get_int("Choose: ");

    if (choice == 0) {
      printf("Time off the charts is time well spent too.\n");
      break;
    } else if (choice == 1) {
      view_portfolio(investments, count);
    } else if (choice == 2) {
      add_investment(investments, &count);
    } else if (choice == 3) {
      total_invested(investments, count);
    } else if (choice == 4) {
      save_to_file(investments, count);
    } else if (choice == 5) {
      load_from_file(investments, &count);
    } else {
      printf("Invalid option.\n");
    }
  }

  return 0;
}
